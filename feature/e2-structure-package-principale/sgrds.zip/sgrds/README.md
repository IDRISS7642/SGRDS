<<<<<<< Updated upstream

<!-- README.md is generated from README.Rmd. Please edit that file -->

<!-- README.md is generated from README.Rmd. Please edit that file -->

# sgrds

=======

<!-- README.md is generated from README.Rmd. Please edit that file -->

# SGRDS — Système de Gestion et de Reporting des Soutenances

>>>>>>> Stashed changes
<!-- badges: start -->

<!-- badges: end -->

**SGRDS** (*Système de Gestion et de Reporting des Soutenances*) est un
<<<<<<< Updated upstream
package R et une application Shiny destinés à centraliser et automatiser
la gestion des impétrants (Master et Doctorat), des notes semestrielles,
des soutenances, des jurys, des avis des rapporteurs et du suivi
administratif du Conseil Scientifique.

## Architecture de la base de données

Le module base de données repose sur **SQLite** et comprend :

- `data/schema.sql` : schéma relationnel complet (8 tables :
  `utilisateurs`, `impetrants`, `notes`, `soutenances`, `jury`,
  `avis_rapporteurs`, `journal`, `photos` et leurs index).
- `data/sgrds.sqlite` : fichier de base de données SQLite initialisé.
- `data/photos/` : répertoire de stockage des fichiers images associés
  aux impétrants.
- `docs/dictionnaire_donnees.md` : dictionnaire détaillé des tables,
  colonnes et règles d’intégrité.
- `R/fct_database.R` : fonctions de connexion, d’exécution de requêtes
  et de lecture des tables (`connecter_bdd()`, `deconnecter_bdd()`,
  `executer_requete()`, `lire_table()`).

## Exemple d’utilisation (Accès à la base)
=======
package R et une application Shiny développés dans le cadre du projet
encadré par le **Dr Dalié**. L’application centralise et automatise la
gestion des impétrants (**Master** et **Doctorat**), le suivi des notes
semestrielles, la planification des soutenances, la composition des
jurys, la collecte des avis des rapporteurs, le stockage des photos de
dossier et la journalisation des opérations administratives du Conseil
Scientifique.

------------------------------------------------------------------------

## Rôle E2 — Architecture et Gestion de la Base de Données

Dans l’organisation de l’équipe projet, le **rôle E2** est dédié à la
conception, l’implémentation, la documentation et la validation de la
couche de persistance des données sous **SQLite**, intégrée directement
à la structure normalisée d’un package R (`usethis::create_package()`).

### Récapitulatif des consignes et livrables réalisés (Tâches 2.1 à 2.4)

| Tâche | Consigne & Objectif technique | Livrables produits |
|:---|:---|:---|
| **Structuration initiale** | Mise en place de l’arborescence standard du package R et préparation de l’environnement de développement sous RStudio / GitHub. | Arborescence `R/`, `data/`, `docs/`, `DESCRIPTION`, `NAMESPACE`, `README.Rmd` |
| **Tâche 2.1 — Schéma SQL** | Conception du modèle relationnel complet à **8 tables**, reprenant les 7 entités de base et intégrant la gestion des photos, les contraintes d’intégrité, les clés étrangères et les index. | `data/schema.sql` |
| **Tâche 2.2 — Base & Dictionnaire** | Génération de la base SQLite opérationnelle, vérification des règles d’unicité (ex. `matricule`) et rédaction d’un dictionnaire de données exhaustif. | `data/sgrds.sqlite` & `docs/dictionnaire_donnees.md` |
| **Tâche 2.3 — Gestion des photos** | Création de la table `photos` reliée à `impetrants`, indexation des requêtes par impétrant et création du répertoire physique de stockage des images. | `data/schema.sql` (table `photos` + index) & `data/photos/` |
| **Tâche 2.4 — Fonctions R & Tests** | Développement et documentation (`roxygen2`) des fonctions standardisées d’accès à la base (`DBI` / `RSQLite`) et validation par des tests d’intégration. | `R/fct_database.R` |

------------------------------------------------------------------------

## Architecture détaillée de la base de données SQLite

### 1. Choix de conception et standardisation SQLite

Pour garantir la portabilité, la robustesse et le respect strict des
consignes du projet : \* **Identifiants techniques** : toutes les clés
primaires utilisent `INTEGER PRIMARY KEY AUTOINCREMENT`. \* **Typage des
chaînes de caractères** : tous les champs alphanumériques (noms,
prénoms, matricules, filières, statuts, chemins de fichiers) sont typés
en `TEXT`. \* **Intégrité référentielle** : activation systématique de
`PRAGMA foreign_keys = ON;` à chaque ouverture de connexion, avec règles
`REFERENCES` et `ON DELETE CASCADE` lorsque pertinent. \* **Contraintes
métier** : contraintes `NOT NULL`, `UNIQUE` (notamment sur `matricule`
dans `impetrants` et `email` / `identifiant` dans `utilisateurs`) et
`CHECK` sur les domaines de valeurs autorisés (niveaux `Master` /
`Doctorat`, rôles, notes, statuts). \* **Indexation** : création d’index
ciblés (dont `idx_photos_impetrant` sur `photos(impetrant_id)`) pour
accélérer les jointures et recherches.

### 2. Les 8 tables du schéma (`data/schema.sql`)

1.  **`utilisateurs`** : gestion des comptes d’accès à l’application
    (rôles administrateur, secrétariat, membre du jury, rapporteur).
2.  **`impetrants`** : registre central des étudiants candidats
    (`matricule` unique, `nom`, `prenom`, `filiere`, `niveau` : `Master`
    ou `Doctorat`, `annee_inscription`, sujet).
3.  **`notes`** : enregistrement et suivi des notes semestrielles par
    impétrant.
4.  **`soutenances`** : planification des soutenances (date, heure,
    salle, note finale, mention attribuée selon les règles propres au
    `Master` ou au `Doctorat`, statut).
5.  **`jury`** : composition des membres du jury associés à chaque
    soutenance (président, directeur de mémoire/thèse, examinateurs).
6.  **`avis_rapporteurs`** : suivi des rapports d’évaluation
    pré-soutenance et décisions des rapporteurs.
7.  **`journal`** : traçabilité et historique des opérations critiques
    effectuées dans le système.
8.  **`photos`** : liaison entre chaque impétrant (`impetrant_id`) et le
    chemin relatif (`chemin_fichier`) de sa photo stockée dans
    `data/photos/`, accompagnée d’une `description` et d’un horodatage
    automatique (`date_ajout`).

### 3. Règles métier documentées (`docs/dictionnaire_donnees.md`)

Le dictionnaire de données formalise pour chacune des 8 tables : \* Le
nom exact des colonnes, leur type SQLite et leur caractère obligatoire
ou facultatif ; \* Les clés primaires, clés étrangères et contraintes
d’unicité ; \* Les règles de gestion associées, incluant la
**distinction des mentions de soutenance entre Master et Doctorat** en
fonction du `niveau` de l’impétrant.

------------------------------------------------------------------------

## Fonctions d’accès à la base (`R/fct_database.R`)

Le fichier `R/fct_database.R` met à disposition de toute l’équipe
(développeurs Shiny, modules métier et reporting) quatre fonctions
standardisées, documentées au format **`roxygen2`** et s’appuyant sur
les packages **`DBI`** et **`RSQLite`** :

- **`connecter_bdd(chemin_bdd)`** : ouvre une connexion SQLite valide
  vers `data/sgrds.sqlite` (vérifie l’existence du fichier ou crée la
  connexion selon le paramètre) et active immédiatement
  `PRAGMA foreign_keys = ON;`.
- **`deconnecter_bdd(con)`** : vérifie la validité de la connexion avec
  `DBI::dbIsValid(con)` et la ferme proprement via
  `DBI::dbDisconnect(con)` afin d’éviter tout verrouillage du fichier
  SQLite.
- **`executer_requete(con, requete, params = NULL)`** : exécute les
  requêtes de modification de structure (`DDL` : `CREATE`, `INDEX`) ou
  de manipulation de données (`DML` : `INSERT`, `UPDATE`, `DELETE`) via
  `DBI::dbExecute()`.
- **`lire_table(con, nom_table)`** : extrait l’intégralité d’une table
  SQLite sous forme de `data.frame` R via `DBI::dbReadTable()` après
  vérification de la connexion et de l’existence de la table.

------------------------------------------------------------------------

## Exemple complet d’utilisation
>>>>>>> Stashed changes

``` r
library(sgrds)

<<<<<<< Updated upstream
# Connexion a la base de donnees SQLite
con <- connecter_bdd("data/sgrds.sqlite")

# Lecture de la table des impetrants
impetrants <- lire_table(con, "impetrants")

# Fermeture propre de la connexion
deconnecter_bdd(con)
```
=======
# 1. Connexion a la base SQLite (PRAGMA foreign_keys = ON active automatiquement)
con <- connecter_bdd("data/sgrds.sqlite")

# 2. Insertion d'un impetrant de test
executer_requete(
  con,
  "INSERT INTO impetrants (matricule, nom, prenom, filiere, niveau, annee_inscription)
   VALUES ('MAT2026_001', 'Kouame', 'Aya', 'Mathematiques', 'Master', 2026);"
)

# 3. Lecture de la table 'impetrants'
impetrants_df <- lire_table(con, "impetrants")
print(impetrants_df)

# 4. Association d'une photo stockee dans data/photos/
id_impetrant <- impetrants_df$id[impetrants_df$matricule == "MAT2026_001"]
executer_requete(
  con,
  sprintf(
    "INSERT INTO photos (impetrant_id, chemin_fichier, description)
     VALUES (%d, 'data/photos/photo_001.jpg', 'Photo officielle du dossier');",
    id_impetrant
  )
)

# 5. Lecture de la table 'photos'
photos_df <- lire_table(con, "photos")
print(photos_df)

# 6. Fermeture propre de la connexion
deconnecter_bdd(con)
```

------------------------------------------------------------------------

## Validation et Tests effectués avant Revue Croisée (Tâche 3)

Avant soumission de la Pull Request, l’ensemble du module base de
données a été validé par les contrôles suivants : 1. **Présence de
l’arborescence et des livrables** : `data/schema.sql`,
`data/sgrds.sqlite`, `data/photos/`, `docs/dictionnaire_donnees.md`,
`R/fct_database.R`, `README.Rmd` et `README.md`. 2. **Intégrité du
schéma** : vérification via `DBI::dbListTables(con)` de la présence
effective des **8 tables** attendues (`utilisateurs`, `impetrants`,
`notes`, `soutenances`, `jury`, `avis_rapporteurs`, `journal`,
`photos`). 3. **Tests des contraintes SQL** : vérification du blocage
automatique des doublons de `matricule` (`UNIQUE constraint failed`) et
du respect des clés étrangères (`FOREIGN KEY constraint failed`). 4.
**Gestion propre des connexions** : vérification systématique après
fermeture que `DBI::dbIsValid(con)` renvoie `FALSE`.
>>>>>>> Stashed changes
